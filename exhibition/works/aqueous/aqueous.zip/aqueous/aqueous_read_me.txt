aqueous					zai 2005
					www.zehao.com
					zehao.chang@gmail.com

This is the source code for my installation aqueous. It runs on Processing and communicates with a valve-controller circuitry. The program has a simulation mode that plays sound samples through Sonia to give an idea of the output of the algorithm.

The black area to the right is a terminal-esque space that shows messages to and from the microcontroller and is used to calibrate the valves, but one can also use it to activate a certain rhythm or music in simulation mode:

e.g.
rhythm 1
(activates rhythm 1)

music 10
(activates music 10)